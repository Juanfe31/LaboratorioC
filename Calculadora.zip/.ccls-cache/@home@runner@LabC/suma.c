#include <stdio.h>
float suma(float a,float b){
    return a+b;
}