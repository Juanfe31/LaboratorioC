
#include "operaciones.h"
#include <stdio.h>

int main() {
  int n;
  float primerValor, segundoValor, aux;
  printf("Ingrese el índice de la operación que desea realizar"
         ":\n\n1:Suma\n2:Resta\n3:Multiplicación\n4:División\n5:"
         "Residuo/Módulo\n6:Potenciación\n7:Raíz cuadrada\n8:Área de un "
         "rectángulo\n9:Perímetro de un rectángulo\n10:Área de un "
         "triángulo\n11:Perímetro de un triángulo\n12:Área de un "
         "círculo\n13:Perímetro/longitud de un "
         "círculo\n14:Descuento\n15:Conversión a número "
         "romano\n16:Factorial\n");
  scanf("%i", &n);
  switch (n) {
  case 1:
    printf("Ingrese el primer número\n");
    scanf("%f", &primerValor);
    printf("Ingrese el segundo número\n");
    scanf("%f", &segundoValor);
    printf("%f", suma(primerValor, segundoValor));
    break;
  case 2:
    printf("Ingrese el minuendo \n");
    scanf("%f", &primerValor);
    printf("Ingrese el sustraendo\n");
    scanf("%f", &segundoValor);
    printf("%f", resta(primerValor, segundoValor));
    break;
  case 3:
    printf("Ingrese el primer número\n");
    scanf("%f", &primerValor);
    printf("Ingrese el segundo número\n");
    scanf("%f", &segundoValor);
    printf("%f", multiplicacion(primerValor, segundoValor));
    break;
  case 4:
    printf("Ingrese el dividendo \n");
    scanf("%f", &primerValor);
    printf("Ingrese el divisor\n");
    scanf("%f", &segundoValor);
    printf("%f", division(primerValor, segundoValor));
    break;
  case 5:
    printf("Ingrese el dividendo \n");
    scanf("%f", &primerValor);
    printf("Ingrese el divisor\n");
    scanf("%f", &segundoValor);
    printf("%i", residuo((int)primerValor, (int)segundoValor));
    break;
  case 6:
    printf("Ingrese la base \n");
    scanf("%f", &primerValor);
    printf("Ingrese la potencia\n");
    scanf("%f", &segundoValor);
    printf("%f", potencia(primerValor, segundoValor));
    break;
  case 7:
    printf("Ingrese el radicando \n");
    scanf("%f", &primerValor);
    printf("%.2f", radicacion(primerValor));
    break;
  case 8:
    printf("Ingrese la base \n");
    scanf("%f", &primerValor);
    printf("Ingrese la altura\n");
    scanf("%f", &segundoValor);
    printf("%f", areaRectangulo(primerValor, segundoValor));
    break;
  case 9:
    printf("Ingrese la base del rectángulo\n");
    scanf("%f", &primerValor);
    printf("Ingrese la altura del rectángulo\n");
    scanf("%f", &segundoValor);
    printf("%f", perimetroRectangulo(primerValor, segundoValor));
    break;
  case 10:
    printf("Ingrese la base del triángulo\n");
    scanf("%f", &primerValor);
    printf("Ingrese la altura del triángulo\n");
    scanf("%f", &segundoValor);
    printf("%f", areaTriangulo(primerValor, segundoValor));
    break;
  case 11:
    printf("Ingrese el tamaño del 1ro lado del triángulo\n");
    scanf("%f", &primerValor);
    printf("Ingrese el tamaño del 2do lado del triángulo\n");
    scanf("%f", &segundoValor);
    printf("Ingrese el tamaño del 3er lado del triángulo\n");
    scanf("%f", &aux);
    printf("%f", perimetroTriangulo(primerValor, segundoValor, aux));
    break;
  case 12:
    printf("Ingrese el radio del círculo\n");
    scanf("%f", &primerValor);
    printf("%f", areaCirculo(primerValor));
    break;
  case 13:
    printf("Ingrese el radio del círculo\n");
    scanf("%f", &primerValor);
    printf("%f", perimetroCirculo(primerValor));
    break;
  case 14:
    printf("Ingrese el monto total\n");
    scanf("%f", &primerValor);
    printf("Ingrese el porcentaje a descontar de forma decimal ej:0.35\n");
    scanf("%f", &segundoValor);
    printf("%f", descuento(primerValor, segundoValor));
    break;
  case 15:
    printf("Ingrese el número que deseea convertir a notación romana\n");
    scanf("%f", &primerValor);
    intToRoman(primerValor);
    break;
  case 16:
    printf("Ingrese el número entero\n");
    scanf("%f", &primerValor);
    printf("%i", factorial((int)primerValor));
    break;
  }
  printf("\n----------------------");
}

//espere este a ver: 45 :OOOOOOOOOO si está bien. MUY TES AMIGA que le hicste
// esteban ya me voy a dormir chao
//Dormir es pa gente que madruga pa clase de 6
// uwuwuwwuwuwuwwuwuwuwuwuwwuwuwuwuwuwuwuwuwwuwuwuuwwuwwuwuwuwuwuwuw
// bueno pues mija, vaya descanse. AL ladito, en files. Ddale en los 3 punticos y download
//chao, la proxima lo dejo solo paque no le imprima
//como lo descargoi por si las moscas?
