#include <stdio.h>
#include <stdlib.h>

float PI = 3.141592653589793238;
float suma(float a, float b) { return a + b; }
float resta(float a, float b) { return a - b; }
float multiplicacion(float a, float b) { return a * b; }
float division(float a, float b) { return a / b; }
int residuo(int a, int b) { return a % b; }
float potencia(float a, float b) {
  float aux = a;
  while ((int)b > 1) {
    a = aux * a;
    b--;
  }
  return a;
}
float radicacion(float radicando) {
  float margen = 0.00001;
  float estimacion = 1.0;

  while (abs((estimacion * estimacion) - radicando) >= margen) {
    float cociente = radicando / estimacion;
    float promedio = (cociente + estimacion) / 2.0;

    estimacion = promedio;
  }
  return estimacion;
}
float areaRectangulo(float a, float b) { return a * b; }
float perimetroRectangulo(float a, float b) { return 2 * (a + b); }
float areaTriangulo(float a, float b) { return (a * b) / 2; }
float perimetroTriangulo(float a, float b, float c) { return c + a + b; }
float areaCirculo(float a) { return a * a * PI; }
float perimetroCirculo(float a) { return 2 * a * PI; }
float descuento(float a, float b) { return a * (1 - b); }
int factorial(int a) {
  int *aux = (int *)malloc(sizeof(int));
  *aux = a;

  while (a > 1) {
    a--;
    *aux = (*aux) * a;
  }
  return (*aux);
}
void intToRoman(int a) {
  // teban si ves esto ya imprime TT_TT

  char m[][3] = {"", "M", "MM", "MMM"};
  char c[][4] = {"", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM "};
  char x[][5] = {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};
  char i[][5] = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};

  char *mil = m[a/1000];
  char *centena = c[(a%1000)/100];
  char *decena = x[(a%100)/10];
  char *unidad = i[a%10];

  printf("%s",mil);
  printf("%s",centena);
  printf("%s",decena);
  printf("%s",unidad);
  

}
