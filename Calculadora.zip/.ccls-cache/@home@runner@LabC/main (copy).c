#include <stdio.h>

int main()
{
    int n;
    scanf("%i", &n);
    int cont = 0;
    int max = 0;
    while (n != 1)
    {
        if (n % 2 == 0) 
        {
            cont++;
            if (cont > max ) {
                max = cont;
            }
        } else {
            cont = 0;
        }
        n = n / 2; 
    }

    printf("%i", max);
    
    
    
}