#include <stdio.h>
float suma(float a, float b) { return a + b; }

float resta(float a, float b) { return a - b; }
